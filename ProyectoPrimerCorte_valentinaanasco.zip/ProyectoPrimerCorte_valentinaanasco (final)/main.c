#include<stdio.h>
/*Para encontrar la representaci�n en binario de un n�mero entre 0 y 255 con 8 bits
Entrada:Valor el cual el usuario desee saber el binario de 8 bitset
Dise�o:Permitir el ingreso del valor
Atravez de una estructura repetitiva poner la condicion de que el numero se encuentre dentro de
0-255 almacenamos el valor a representar en una variable entera. Posteriormente, a partir de la m�xima potencia de 2
que se puede almacenar en 8 bits (128), vamos �apagando� de izquierda a derecha aquellos bits
cuyo valor exceda el valor actual de la variable y dejando �encendido� el bit cuya potencia de 2
correspondiente sea menor o igual al valor de la variable. Cada vez que dejamos un bit encendido,
restamos el valor de la potencia de 2 correspondiente a la variable, hasta llegar a la primera
potencia de 2 (2^0). Si en alg�n momento el valor de la variable es 0, los dem�s bits hasta la primera
potencia de 2 ser�n 0.
*/
/**
*@file
*@brief Proyecto 1
*@autor Valentina A�asco Concha <valentinaanasco@unicauca.edu.co>
*/
int main (){
	int valorOriginal;
	printf("Representaci�n de un n�mero entero entre 0 y 255 en binarios de 8 bits\n");
	do{
		printf("ingrese un n�mero entre 0 y 255:");
		scanf("%i",&valorOriginal);
		if(valorOriginal<0||valorOriginal>255){
			printf("Este n�mero no esta dento del rango requerido, intente nuevamente\n");
		}
	}while(valorOriginal<0||valorOriginal>256);
	
	printf("El n�mero binario de %d es: ",valorOriginal);
	for (int i = 7; i >= 0; i--) {
		int bit = (valorOriginal >> i) & 1; // Extraer el bit en la posici�n i
		printf( "%d",bit);
	}
	return 0;
}
